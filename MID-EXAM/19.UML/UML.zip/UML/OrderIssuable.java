package com.government;

public interface OrderIssuable {
    public String order();
}

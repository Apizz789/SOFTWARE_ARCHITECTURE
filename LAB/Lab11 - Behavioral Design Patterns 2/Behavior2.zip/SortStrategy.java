package edu.parinya.softarchdesign.behavior2;

// DO NOT MODIFY ANYTHING BELOW THIS LINE!!
import java.util.List;

public interface SortStrategy {
    void customSort(List<Person> people);
}
